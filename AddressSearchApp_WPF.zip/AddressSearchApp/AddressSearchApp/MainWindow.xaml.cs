﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace AddressSearchApp
{
    public partial class MainWindow : Window
    {
        // Ensure ViewModel property works by setting the DataContext
        private MainWindowViewModel ViewModel => DataContext as MainWindowViewModel;

        public MainWindow()
        {
            InitializeComponent();

            // Set the DataContext to the ViewModel
            DataContext = new MainWindowViewModel();
        }

        // This method is called when the text in the TextBox changes
        //private async void OnAddressSearchTextChanged(object sender, TextChangedEventArgs e)
        //{
        //    if (!string.IsNullOrWhiteSpace(ViewModel?.AddressSearchQuery)) // Check if ViewModel is not null
        //    {
        //        await ViewModel.SearchAddressAsync(ViewModel.AddressSearchQuery);
        //    }
        //}

        private void ComboBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (sender is ComboBox comboBox)
            {
                // Open the drop-down when any key is pressed
                if (!comboBox.IsDropDownOpen)
                {
                    comboBox.IsDropDownOpen = true;
                }
            }
        }
    }
}
