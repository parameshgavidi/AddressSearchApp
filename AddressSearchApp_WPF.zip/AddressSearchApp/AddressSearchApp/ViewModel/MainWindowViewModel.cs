﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading.Tasks;

namespace AddressSearchApp
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private string addressSearchQuery;
        private ObservableCollection<string> addressSuggestions;
        private string selectedAddress;
        private string fullAddress;

        public MainWindowViewModel()
        {
            AddressSuggestions = new ObservableCollection<string>();
        }

        public string AddressSearchQuery
        {
            get => addressSearchQuery;
            set
            {
                addressSearchQuery = value;
                OnPropertyChanged();
                if (!string.IsNullOrWhiteSpace(value))
                {
                    // Trigger the search when the query changes
                    SearchAddressAsync(value);
                }
                else
                {
                    // Clear suggestions if the query is empty
                    AddressSuggestions.Clear();
                }
            }
        }

        public ObservableCollection<string> AddressSuggestions
        {
            get => addressSuggestions;
            set
            {
                addressSuggestions = value;
                OnPropertyChanged();
            }
        }

        public string SelectedAddress
        {
            get => selectedAddress;
            set
            {
                selectedAddress = value;
                if (value != null)
                {
                    // Update FullAddress when an address is selected
                    FullAddress = $"Full Address: {selectedAddress}, City, Country";
                }
                OnPropertyChanged();
            }
        }

        public string FullAddress
        {
            get => fullAddress;
            set
            {
                fullAddress = value;
                OnPropertyChanged();
            }
        }

        // Call a third-party RESTful API to get address suggestions
        private async Task SearchAddressAsync(string query)
        {
            AddressSuggestions.Clear();
            if (string.IsNullOrWhiteSpace(query))
            {
                return;
            }

            // Use HttpClient to make an API call to get address suggestions
            try
            {
                //using var httpClient = new HttpClient();
                //var apiUrl = $"https://api.example.com/get-address-suggestions?q={query}";  // Replace with actual API URL
                //var response = await httpClient.GetAsync(apiUrl);

                //if (response.IsSuccessStatusCode)
                //{
                //    // Deserialize the JSON response into a list of suggestions
                //    var jsonResponse = await response.Content.ReadAsStringAsync();
                //    var suggestions = JsonSerializer.Deserialize<string[]>(jsonResponse);

                //    // Update AddressSuggestions
                //    AddressSuggestions = new ObservableCollection<string>(suggestions);
                //}
                //else
                //{
                //    // Handle API failure
                //    AddressSuggestions.Clear();
                //}

                AddressSuggestions.Clear();

                // Simulate new address suggestions
                AddressSuggestions.Add($"{query} Address 1");
                AddressSuggestions.Add($"{query} Address 2");
                AddressSuggestions.Add($"{query} Street");
                AddressSuggestions.Add($"{query} Avenue");
                AddressSuggestions.Add($"{query} Boulevard");
            }
            catch (Exception ex)
            {
                // Handle exceptions (network errors, etc.)
                AddressSuggestions.Clear();
                Console.WriteLine($"Error fetching address suggestions: {ex.Message}");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
