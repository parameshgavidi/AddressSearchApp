﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        txtParameters = New TextBox()
        lblsearchAddress = New Label()
        lblEnterAddress = New Label()
        txtEnterAddress = New TextBox()
        btnSend = New Button()
        SuspendLayout()
        ' 
        ' txtParameters
        ' 
        txtParameters.Location = New Point(227, 55)
        txtParameters.Name = "txtParameters"
        txtParameters.Size = New Size(459, 27)
        txtParameters.TabIndex = 1
        ' 
        ' lblsearchAddress
        ' 
        lblsearchAddress.AutoSize = True
        lblsearchAddress.Location = New Point(71, 62)
        lblsearchAddress.Name = "lblsearchAddress"
        lblsearchAddress.Size = New Size(110, 20)
        lblsearchAddress.TabIndex = 2
        lblsearchAddress.Text = "Search Address"
        lblsearchAddress.TextAlign = ContentAlignment.TopCenter
        ' 
        ' lblEnterAddress
        ' 
        lblEnterAddress.AutoSize = True
        lblEnterAddress.Location = New Point(70, 118)
        lblEnterAddress.Name = "lblEnterAddress"
        lblEnterAddress.Size = New Size(100, 20)
        lblEnterAddress.TabIndex = 3
        lblEnterAddress.Text = "Enter Address"
        ' 
        ' txtEnterAddress
        ' 
        txtEnterAddress.Location = New Point(225, 118)
        txtEnterAddress.Name = "txtEnterAddress"
        txtEnterAddress.Size = New Size(461, 27)
        txtEnterAddress.TabIndex = 4
        ' 
        ' btnSend
        ' 
        btnSend.Location = New Point(233, 181)
        btnSend.Name = "btnSend"
        btnSend.Size = New Size(180, 29)
        btnSend.TabIndex = 5
        btnSend.Text = "Confirm Address"
        btnSend.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(btnSend)
        Controls.Add(txtEnterAddress)
        Controls.Add(lblEnterAddress)
        Controls.Add(lblsearchAddress)
        Controls.Add(txtParameters)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtParameters As TextBox
    Friend WithEvents lblsearchAddress As Label
    Friend WithEvents lblEnterAddress As Label
    Friend WithEvents txtEnterAddress As TextBox
    Friend WithEvents btnSend As Button

End Class
