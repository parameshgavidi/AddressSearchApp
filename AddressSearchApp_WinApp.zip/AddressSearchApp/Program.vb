﻿Imports System.Windows.Forms

Module Program
    Public Sub Main()
        ' Enable visual styles and set text rendering compatibility
        Application.EnableVisualStyles()
        Application.SetCompatibleTextRenderingDefault(False)

        ' Retrieve command-line arguments
        Dim args() As String = Environment.GetCommandLineArgs()

        ' Debugging line to output arguments
        For i As Integer = 0 To args.Length - 1
            Debug.WriteLine($"Argument {i}: {args(i)}")
        Next

        ' Instantiate Form1 with arguments
        Dim form As New Form1(args) ' This should call the constructor that accepts args
        Application.Run(form)
    End Sub
End Module
