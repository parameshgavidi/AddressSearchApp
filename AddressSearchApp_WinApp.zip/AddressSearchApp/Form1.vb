﻿Imports System.Reflection.Emit

Public Class Form1
    ' Default constructor
    Public Sub New()
        InitializeComponent()
        txtParameters.Text = "Default No parameters received." ' Default message
    End Sub

    ' Constructor that takes command-line arguments
    Public Sub New(args As String())
        InitializeComponent() ' Required call to initialize components
        DisplayParameters(args) ' Call to handle the parameters
    End Sub

    Private Sub DisplayParameters(args As String())
        If args.Length > 1 Then ' args(0) is the application path
            ' Remove protocol prefix (e.g., "myapp://") from the first parameter if present
            Dim parameterString As String = args(1).Replace("myapp://", "")
            Dim parameters = parameterString.Split("&"c)

            Dim displayText As String = "Parameters received:" & vbCrLf
            For Each param As String In parameters
                Dim keyValue = param.Split("="c)
                If keyValue.Length = 2 Then
                    Dim key = keyValue(0)
                    Dim value = keyValue(1)
                    displayText &= $"Parameter: {key}, Value: {value}" & vbCrLf
                End If
            Next

            ' Display parameters in the Label
            txtParameters.Text = displayText
        Else
            txtParameters.Text = "No parameters received."
        End If
    End Sub


    'Private Sub btnSend_Click(sender As Object, e As EventArgs) Handles btnSend.Click
    '    Dim inputText As String = txtEnterAddress.Text
    '    Dim encodedText As String = Uri.EscapeDataString(inputText) ' URL encode the text

    '    ' Open the URL directly in the default web browser
    '    Dim url As String = $"http://localhost:5000/?inputText={encodedText}"

    '    ' Use Process.Start to open the URL directly
    '    Process.Start(New ProcessStartInfo(url) With {.UseShellExecute = True})
    '    'Process.Start(New ProcessStartInfo("cmd", $"/c start {url}") With {.CreateNoWindow = True})
    'End Sub


    Private Sub btnSend_Click(sender As Object, e As EventArgs) Handles btnSend.Click
        Dim inputText As String = txtEnterAddress.Text
        Dim encodedText As String = Uri.EscapeDataString(inputText) ' URL encode the text

        ' Construct the URL for the web application to update the input text
        Dim url As String = $"http://localhost:5000/?inputText={encodedText}"

        ' Open the URL in the current browser tab
        Process.Start(New ProcessStartInfo(url) With {.UseShellExecute = True})
    End Sub


End Class
