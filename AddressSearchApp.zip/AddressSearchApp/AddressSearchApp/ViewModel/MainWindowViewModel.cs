﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace AddressSearchApp
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private string addressSearchQuery;
        private ObservableCollection<string> addressSuggestions;
        private string selectedAddress;
        private string fullAddress;
        private bool isAddressSelected;

        public MainWindowViewModel()
        {
            AddressSuggestions = new ObservableCollection<string>();
        }

        public string AddressSearchQuery
        {
            get => addressSearchQuery;
            set
            {
                addressSearchQuery = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<string> AddressSuggestions
        {
            get => addressSuggestions;
            set
            {
                addressSuggestions = value;
                OnPropertyChanged();
            }
        }

        public string SelectedAddress
        {
            get => selectedAddress;
            set
            {
                selectedAddress = value;
                if (value != null)
                {
                    // Simulate filling out the full address
                    FullAddress = GetFullAddress(value);
                    IsAddressSelected = true;
                }
                OnPropertyChanged();
            }
        }

        public string FullAddress
        {
            get => fullAddress;
            set
            {
                fullAddress = value;
                OnPropertyChanged();
            }
        }

        public bool IsAddressSelected
        {
            get => isAddressSelected;
            set
            {
                isAddressSelected = value;
                OnPropertyChanged();
            }
        }

        // Simulate an async search call to a third-party address service
        public async Task SearchAddressAsync(string query)
        {
            if (string.IsNullOrWhiteSpace(query)) return;

            // Simulating an async call to a third-party address service
            await Task.Delay(500); // Simulate delay from API call

            var simulatedResults = new[]
            {
                $"{query} Street 1",
                $"{query} Street 2",
                $"{query} Avenue",
                $"{query} Road"
            };

            AddressSuggestions = new ObservableCollection<string>(simulatedResults);
        }

        private string GetFullAddress(string selectedAddress)
        {
            // Simulate filling out full address details
            return $"Full Address: {selectedAddress}, City, Country";
        }

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
