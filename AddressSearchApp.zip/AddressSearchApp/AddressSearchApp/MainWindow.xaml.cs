﻿using System.Windows;
using System.Windows.Controls;

namespace AddressSearchApp
{
    public partial class MainWindow : Window
    {
        // Ensure ViewModel property works by setting the DataContext
        private MainWindowViewModel ViewModel => DataContext as MainWindowViewModel;

        public MainWindow()
        {
            InitializeComponent();

            // Set the DataContext to the ViewModel
            DataContext = new MainWindowViewModel();
        }

        // This method is called when the text in the TextBox changes
        private async void OnAddressSearchTextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(ViewModel?.AddressSearchQuery)) // Check if ViewModel is not null
            {
                await ViewModel.SearchAddressAsync(ViewModel.AddressSearchQuery);
            }
        }
    }
}
